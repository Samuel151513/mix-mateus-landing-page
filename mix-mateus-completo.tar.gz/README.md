# Mix Mateus Landing Page - Deploy Completo

## 📁 Estrutura

Este arquivo contém TODAS as 19 páginas do sistema Mix Mateus, cada uma em sua pasta numerada.

## 📂 Pastas Criadas:

- **1/** - Home
- **2/** - Verification
- **3/** - Analysis
- **4/** - Card Approved
- **5/** - Due Date Selection
- **6/** - Benefits
- **7/** - Limit Growth
- **8/** - Manager Contact
- **9/** - Terms
- **10/** - Dashboard
- **11/** - Card Delivery
- **12/** - Delivery Address
- **13/** - Shipping Method
- **14/** - SEDEX Processing
- **15/** - SEDEX Payment
- **20/** - EXPRESS Processing
- **21/** - EXPRESS Payment
- **30/** - PAC Processing
- **31/** - PAC Payment

## 🚀 Como Usar no Hostinger:

1. **Extraia este ZIP** na raiz da sua hospedagem (public_html/)
2. **Estrutura final** será:
   - public_html/1/ (página inicial)
   - public_html/2/ (verificação)
   - public_html/3/ (análise)
   - ... até public_html/31/

3. **Acesse:** https://seudominio.com/1/

## 🔗 Navegação:

- Página inicial: /1/
- Verificação: /2/
- Análise: /3/
- ... e assim por diante

## ⚙️ Configurações:

- ✅ Cada pasta tem seu próprio .htaccess
- ✅ Cada pasta tem todos os assets necessários
- ✅ Sistema de navegação hash-based (funciona em subpastas)
- ✅ Links de checkout já configurados

## 💳 Checkout Links:

- **SEDEX:** R$ 34,90 - 1 dia útil
- **EXPRESS:** R$ 32,00 - 5 dias úteis  
- **PAC:** R$ 29,90 - 10 dias úteis

## 🎨 Branding:

- Cor Azul: #0D6EFD (HSL: 214, 85%, 50%)
- Cor Vermelha: #F0263C (HSL: 358, 85%, 55%)
- Limite fixo: R$ 3.750,00

---

**Versão 19.0** - Sistema completo com checkout configurado
**Data:** 18/11/2025
